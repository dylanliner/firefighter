package com.takehome.firefighter.infrastructure.persistence;

import com.takehome.firefighter.infrastructure.controller.TeamDTO;
import com.takehome.firefighter.usecases.Firefighter;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "FIREFIGHTER")
public class FirefighterEntity {

    @Id
    private UUID id;

    private String name;

    @ManyToOne
    @JoinColumn(name = "TEAM_id")
    private TeamEntity team;


    public static FirefighterEntity toEntity(Firefighter firefighter) {
        return new FirefighterEntity(firefighter.getId(), firefighter.getName(), TeamEntity.toEntity(firefighter.getTeam()));
    }

    public Firefighter toDomain() {
        return new Firefighter(id, name, team.toDomain());
    }


    public FirefighterEntity(UUID id, String name, TeamEntity team) {
        this.id = id;
        this.name = name;
        this.team = team;
    }

    public FirefighterEntity() {
    }
}
