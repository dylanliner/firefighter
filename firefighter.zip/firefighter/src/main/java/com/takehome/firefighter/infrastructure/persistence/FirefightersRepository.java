package com.takehome.firefighter.infrastructure.persistence;

import com.takehome.firefighter.usecases.Firefighter;
import org.springframework.data.repository.Repository;

import java.util.UUID;

public interface FirefightersRepository {

    Firefighter findNextFirefighter(Firefighter currentFirefighterName);

    void saveFirefighter(Firefighter firefighter);

    void delete(UUID firefighterId);

}
