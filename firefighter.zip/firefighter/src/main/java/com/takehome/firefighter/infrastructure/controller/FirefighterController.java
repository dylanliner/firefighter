package com.takehome.firefighter.infrastructure.controller;

import com.takehome.firefighter.usecases.CreateFirefighterUseCase;
import com.takehome.firefighter.usecases.DeleteFirefighterUseCase;
import com.takehome.firefighter.usecases.DesignateFirefighterUsecase;
import com.takehome.firefighter.usecases.ReadFirefighterHistoryUseCase;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
public class FirefighterController {

    private final DesignateFirefighterUsecase designateFirefighterUsecase;

    private final ReadFirefighterHistoryUseCase readFirefighterHistoryUseCase;

    private final DeleteFirefighterUseCase deleteFirefighterUseCase;

    private final CreateFirefighterUseCase createFirefighterUseCase;

    public FirefighterController(DesignateFirefighterUsecase designateFirefighterUsecase, ReadFirefighterHistoryUseCase readFirefighterHistoryUseCase, DeleteFirefighterUseCase deleteFirefighterUseCase, CreateFirefighterUseCase createFirefighterUseCase) {
        this.designateFirefighterUsecase = designateFirefighterUsecase;
        this.readFirefighterHistoryUseCase = readFirefighterHistoryUseCase;
        this.deleteFirefighterUseCase = deleteFirefighterUseCase;
        this.createFirefighterUseCase = createFirefighterUseCase;
    }

    @PostMapping("/firefighter/designateFirefighter")
    ResponseEntity<FirefighterDTO> designateFirefighter() {
        var firefighter = designateFirefighterUsecase.designateFirefighter();
        return ResponseEntity.of(Optional.of(FirefighterDTO.toDTO(firefighter)));
    }

    @PostMapping("/firefighter")
    ResponseEntity<Void> createFirefighter(@RequestBody FirefighterRequest firefighterRequest) {
        createFirefighterUseCase.createFirefighter(firefighterRequest.toDomain());
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/firefighter")
    ResponseEntity<List<FirefighterHistoryDTO>> getFirefighterHistory() {
        var firefighterHistoryList = readFirefighterHistoryUseCase.findAllFirefighterHistory();
        return ResponseEntity.of(Optional.of(firefighterHistoryList.stream().map(FirefighterHistoryDTO::toDto).collect(Collectors.toList())));
    }

    @DeleteMapping("/firefighter/{firefighterId}")
    ResponseEntity<Void> deleteFirefighter(@PathVariable UUID firefighterId) {
        deleteFirefighterUseCase.deleteFirefighter(firefighterId);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }


}
