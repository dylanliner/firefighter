package com.takehome.firefighter.infrastructure.persistence;

import com.takehome.firefighter.usecases.Firefighter;

import java.util.UUID;

public interface CurrentFirefighterRepository {

    Firefighter findPreviousFirefighter();

    void updateCurrentFirefighter(UUID currentFirefighterId);
}
