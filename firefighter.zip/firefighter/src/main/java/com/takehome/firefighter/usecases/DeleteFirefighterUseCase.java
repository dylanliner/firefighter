package com.takehome.firefighter.usecases;

import com.takehome.firefighter.infrastructure.persistence.FirefightersRepository;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class DeleteFirefighterUseCase {

    private final FirefightersRepository firefightersRepository;

    public DeleteFirefighterUseCase(FirefightersRepository firefightersRepository) {
        this.firefightersRepository = firefightersRepository;
    }

    public void deleteFirefighter(UUID firefighterId){
        firefightersRepository.delete(firefighterId);
    }
}
