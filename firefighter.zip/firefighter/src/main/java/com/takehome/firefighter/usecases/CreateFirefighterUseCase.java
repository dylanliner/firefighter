package com.takehome.firefighter.usecases;

import com.takehome.firefighter.infrastructure.persistence.FirefightersRepository;
import org.springframework.stereotype.Service;

@Service
public class CreateFirefighterUseCase {

    private final FirefightersRepository firefightersRepository;

    public CreateFirefighterUseCase(FirefightersRepository firefightersRepository) {
        this.firefightersRepository = firefightersRepository;
    }

    public void createFirefighter(Firefighter firefighter) {
        firefightersRepository.saveFirefighter(firefighter);
    }
}
