package com.takehome.firefighter.infrastructure.persistence;

import com.takehome.firefighter.usecases.Firefighter;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface CurrentFirefighterEntityH2Repository extends JpaRepository<CurrentFirefighterEntity, UUID> {

}
