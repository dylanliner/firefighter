package com.takehome.firefighter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirefighterApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirefighterApplication.class, args);
	}

}
