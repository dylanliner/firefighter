package com.takehome.firefighter.infrastructure.controller;

import com.takehome.firefighter.usecases.Firefighter;
import com.takehome.firefighter.usecases.Team;

import java.util.UUID;

public class FirefighterRequest {

    private String name;
    private UUID teamId;

    public String getName() {
        return name;
    }

    public UUID getTeamId() {
        return teamId;
    }

    public Firefighter toDomain() {
        return new Firefighter(UUID.randomUUID(), name, new Team(teamId, null));
    }
}
