package com.takehome.firefighter.usecases;

import com.takehome.firefighter.infrastructure.persistence.FirefighterHistoryRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class ReadFirefighterHistoryUseCase {

    private final FirefighterHistoryRepository firefighterHistoryRepository;

    public ReadFirefighterHistoryUseCase(FirefighterHistoryRepository firefighterHistoryRepository) {
        this.firefighterHistoryRepository = firefighterHistoryRepository;
    }


    @Transactional
    public List<FirefighterHistory> findAllFirefighterHistory() {
        return firefighterHistoryRepository.findAllFirefighterHistory();
    }
}
