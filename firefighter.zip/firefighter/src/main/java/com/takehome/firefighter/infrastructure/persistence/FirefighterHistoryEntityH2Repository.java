package com.takehome.firefighter.infrastructure.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface FirefighterHistoryEntityH2Repository extends JpaRepository<FirefighterHistoryEntity, UUID> {

}
