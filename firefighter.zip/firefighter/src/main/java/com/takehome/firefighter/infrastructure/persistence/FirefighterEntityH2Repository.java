package com.takehome.firefighter.infrastructure.persistence;

import com.takehome.firefighter.usecases.Firefighter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import java.util.List;
import java.util.UUID;

public interface FirefighterEntityH2Repository extends JpaRepository<FirefighterEntity, UUID> {


    @Query(value = "select * from FIREFIGHTER f where f.name >= ?2 and f.id != ?1 order by f.name ASC limit 1", nativeQuery = true)
    FirefighterEntity findNextFirefighter(UUID currentFirefighterid, String currentFirefighterName);

    @Query(value = "select * from FIREFIGHTER f order by f.name ASC limit 1", nativeQuery = true)
    FirefighterEntity findFirstFirefighterAlphabetically();
}
