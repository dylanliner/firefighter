package com.takehome.firefighter.infrastructure.persistence;

import com.takehome.firefighter.usecases.Firefighter;
import com.takehome.firefighter.usecases.FirefighterHistory;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

public interface FirefighterHistoryRepository {

    void updateFireFighterHistory(UUID currentFirefighter, ZonedDateTime date);

    List<FirefighterHistory> findAllFirefighterHistory();
}
