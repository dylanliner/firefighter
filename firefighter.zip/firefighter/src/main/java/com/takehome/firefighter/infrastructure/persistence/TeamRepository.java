package com.takehome.firefighter.infrastructure.persistence;

import com.takehome.firefighter.usecases.FirefighterHistory;
import com.takehome.firefighter.usecases.Team;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

public interface TeamRepository {

    void save(Team team);

    Team findById(UUID teamId);
}
