package com.takehome.firefighter.infrastructure.persistence;

import com.takehome.firefighter.usecases.Firefighter;
import com.takehome.firefighter.usecases.Team;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.transaction.Transactional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@Transactional
@SpringBootTest
class FirefightersH2RepositoryTest {

    @Autowired
    FirefightersH2Repository firefighterH2Repository;

    @Autowired
    TeamH2Repository teamH2Repository;


    @BeforeEach
    public void clean() {
        firefighterH2Repository.deleteAll();
        teamH2Repository.deleteAll();
    }

    @Test
    public void shouldFindNextFirefighter_whenOtherFirefightersWithDifferentNames() {
        //GIVEN
        var team1 = new Team(UUID.randomUUID(), "team");
        teamH2Repository.save(team1);

        var firefighter1 = new Firefighter(UUID.randomUUID(), "name", team1);
        var firefighter2 = new Firefighter(UUID.randomUUID(), "name1", team1);
        var firefighter3 = new Firefighter(UUID.randomUUID(), "name2", team1);
        firefighterH2Repository.saveFirefighter(firefighter2);
        firefighterH2Repository.saveFirefighter(firefighter1);
        firefighterH2Repository.saveFirefighter(firefighter3);

        //WHEN
        var actualCurrentFirefighter = firefighterH2Repository.findNextFirefighter(firefighter1);

        //THEN
        assertThat(actualCurrentFirefighter).isEqualTo(firefighter2);
    }

    @Test
    public void shouldFindNextFirefighter_whenOtherFirefightersWithSameNames() {
        //GIVEN
        var team1 = new Team(UUID.randomUUID(), "team");
        var team2 = new Team(UUID.randomUUID(), "team2");
        var team3 = new Team(UUID.randomUUID(), "team3");
        teamH2Repository.save(team1);
        teamH2Repository.save(team2);
        teamH2Repository.save(team3);
        var firefighter1 = new Firefighter(UUID.randomUUID(), "name", team1);
        var firefighter2 = new Firefighter(UUID.randomUUID(), "name", team2);
        var firefighter3 = new Firefighter(UUID.randomUUID(), "name", team3);
        firefighterH2Repository.saveFirefighter(firefighter2);
        firefighterH2Repository.saveFirefighter(firefighter1);
        firefighterH2Repository.saveFirefighter(firefighter3);

        //WHEN
        var actualCurrentFirefighter = firefighterH2Repository.findNextFirefighter(firefighter2);

        //THEN
        assertThat(actualCurrentFirefighter).isEqualTo(firefighter1);
    }

    @Test
    public void shouldFindNextFirefighter_whenFirefighterIsUnique() {
        //GIVEN
        var team1 = new Team(UUID.randomUUID(), "team");
        var firefighter1 = new Firefighter(UUID.randomUUID(), "name", team1);
        teamH2Repository.save(team1);
        firefighterH2Repository.saveFirefighter(firefighter1);

        //WHEN
        var actualCurrentFirefighter = firefighterH2Repository.findNextFirefighter(firefighter1);

        //THEN
        assertThat(actualCurrentFirefighter).isEqualTo(firefighter1);
    }

    @Test
    public void shouldFindNull_whenNoFirefighter() {
        //GIVEN
        var team1 = new Team(UUID.randomUUID(), "team");
        var firefighter1 = new Firefighter(UUID.randomUUID(), "name", team1);

        //WHEN
        var actualCurrentFirefighter = firefighterH2Repository.findNextFirefighter(firefighter1);

        //THEN
        assertThat(actualCurrentFirefighter).isNull();
    }

    @Test
    public void shouldFindNextFirefighter_whenNoMoreFirefighterAlphabetically() {
        //GIVEN
        var team1 = new Team(UUID.randomUUID(), "team");
        var firefighter1 = new Firefighter(UUID.randomUUID(), "name", team1);
        var firefighter2 = new Firefighter(UUID.randomUUID(), "name1", team1);
        var firefighter3 = new Firefighter(UUID.randomUUID(), "name2", team1);
        teamH2Repository.save(team1);
        firefighterH2Repository.saveFirefighter(firefighter1);
        firefighterH2Repository.saveFirefighter(firefighter2);
        firefighterH2Repository.saveFirefighter(firefighter3);

        //WHEN
        var actualCurrentFirefighter = firefighterH2Repository.findNextFirefighter(firefighter3);

        //THEN
        assertThat(actualCurrentFirefighter).isEqualTo(firefighter1);
    }

    @Test
    public void shouldDeleteFirefighter_whenFirefighterexists() {
        //GIVEN
        var team1 = new Team(UUID.randomUUID(), "team");
        var firefighter1 = new Firefighter(UUID.randomUUID(), "name", team1);
        teamH2Repository.save(team1);
        firefighterH2Repository.saveFirefighter(firefighter1);

        //WHEN
        firefighterH2Repository.delete(firefighter1.getId());

        //THEN
        var actualCurrentFirefighter = firefighterH2Repository.findAll();
        assertThat(actualCurrentFirefighter).isEmpty();
    }

}