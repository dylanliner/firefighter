package com.takehome.firefighter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirefighterApplicationTests {

	@Test
	void contextLoads() {
	}

}
